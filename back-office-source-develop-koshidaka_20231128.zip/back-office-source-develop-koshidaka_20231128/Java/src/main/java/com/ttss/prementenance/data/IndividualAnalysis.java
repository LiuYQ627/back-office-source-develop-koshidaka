package com.ttss.prementenance.data;

import lombok.Data;

@Data
public class IndividualAnalysis {
    private String inquiryCode;
    private String price;
}
