package com.ttss.prementenance.model;

import lombok.Data;

@Data
public class DataClearTableKindMappingModel {
    private int tableCategory;
    private String categoryName;
}
