// KSD V001.000 AS 2023.12.13 refs #89921 時間帯設定が店舗マスタ保存後に元に戻ってしまう
package com.ttss.prementenance.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * HOURZONE_LIST データモデル データモデル.
 *
 * @author
 * @version 1.0.0
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConfigurationsHourZoneListModel {
    public ConfigurationsHourZoneListModel() {}

	// type --------------------------------------------//
	/**
	 * type
	 */
	private String type;
	/**
	 * typeゲッター.
	 *
	 * @return type
	 */
	public String getType() {
		return type;
	}
	/**
	 * typeセッター.
	 *
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	// type --------------------------------------------//

	// group -------------------------------------------//
	/**
	 * group
	 */
	private String group;
	/**
	 * groupゲッター.
	 *
	 * @return group
	 */
	public String getGroup() {
		return group;
	}
	/**
	 * group.
	 *
	 * @param group
	 */
	public void setGroup(String group) {
		this.group = group;
	}
	// group -------------------------------------------//

	// subGroup-----------------------------------------//
	/**
	 * subGroup
	 */
	private String subGroup;
	/**
	 * subGroupゲッター.
	 *
	 * @return subGroup
	 */
	public String getSubGroup() {
		return subGroup;
	}
	/**
	 * subGroup.
	 *
	 * @param subGroup
	 */
	public void setSubGroup(String subGroup) {
		this.subGroup = subGroup;
	}
	// subGroup-----------------------------------------//

	// name --------------------------------------------//
	/**
	 * name
	 */
	private String name;
	/**
	 * nameゲッター.
	 *
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * name.
	 *
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	// name --------------------------------------------//

	// value -------------------------------------------//
	/**
	 * value
	 */
	private List<ConfigurationsHourZoneListDetailModel> value;
	/**
	 * valueゲッター.
	 *
	 * @return value
	 */
	public List<ConfigurationsHourZoneListDetailModel> getValue() {
		return value;
	}
	/**
	 * value.
	 *
	 * @param value
	 */
	public void setValue(List<ConfigurationsHourZoneListDetailModel> value) {
		this.value = value;
	}
	// value -------------------------------------------//

}
// KSD V001.000 AE 2023.12.13 refs #89921 時間帯設定が店舗マスタ保存後に元に戻ってしまう
