package com.ttss.prementenance.model;

import lombok.Data;

/** データクリア対象テーブルマッピング データモデル */
@Data
public class AccessAuthorityChangeplanModel {
	private String name;
	private boolean deleted;
}
