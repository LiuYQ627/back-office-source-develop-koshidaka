package com.ttss.prementenance.model;

import lombok.Data;

@Data
public class GetAccessAuthorityRequestModel {

}
