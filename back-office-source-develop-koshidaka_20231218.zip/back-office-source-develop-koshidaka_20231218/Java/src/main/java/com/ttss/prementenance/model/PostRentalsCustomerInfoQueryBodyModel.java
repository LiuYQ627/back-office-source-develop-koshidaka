//KSD V001.000 20231128 AS
package com.ttss.prementenance.model;


import java.util.List;

import lombok.Data;

/**
 * Rentals 顧客情報ファイルアイテム取得  ボディ データモデル.
 *
 * @author 
 * @version 1.0.0
 */
@Data
public class PostRentalsCustomerInfoQueryBodyModel {
	public PostRentalsCustomerInfoQueryBodyModel() {}

	/* nodeId */
	private List<String> nodeId;
	public List<String> getNodeId() {
		return nodeId;
	}
	public void setNodeId(List<String> nodeId) {
		this.nodeId = nodeId;
	}
	/* indexNo */
	private List<Long> indexNo;
	public List<Long> getIndexNo() {
		return indexNo;
	}
	public void setIndexNo(List<Long> indexNo) {
		this.indexNo = indexNo;
	}
	public boolean isTrainingMode;
	public boolean getIsTrainingMode() {
		return isTrainingMode;
	}
	public void setIsTrainingMode(boolean isTrainingMode) {
		this.isTrainingMode = isTrainingMode;
	}

}
//KSD V001.000 20231128 AE

