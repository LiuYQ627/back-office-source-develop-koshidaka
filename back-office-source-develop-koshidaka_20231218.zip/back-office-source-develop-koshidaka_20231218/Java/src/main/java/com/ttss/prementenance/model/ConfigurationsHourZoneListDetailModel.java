// KSD V001.000 AS 2023.12.13 refs #89921 時間帯設定が店舗マスタ保存後に元に戻ってしまう
package com.ttss.prementenance.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * TAX_SETS データモデル データモデル.
 *
 * @author
 * @version 1.0.0
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConfigurationsHourZoneListDetailModel {
    public ConfigurationsHourZoneListDetailModel() {}

	// order -------------------------------------------//
	/**
	 * order
	 */
	private Integer order;

	/**
	 * orderゲッター.
	 *
	 * @return order
	 */
	public Integer getOrder() {
		return order;
	}

	/**
	 * orderセッター
	 *
	 * @param order order
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}
	// order -------------------------------------------//

	// hourZone ----------------------------------------//
	/**
	 * hourZone
	 */
	private String hourZone;

	/**
	 * hourZoneゲッター.
	 *
	 * @return hourZone
	 */
	public String getHourZone() {
		return hourZone;
	}

	/**
	 * hourZoneセッター
	 *
	 * @param hourZone hourZone
	 */
	public void setHourZone(String hourZone) {
		this.hourZone = hourZone;
	}
	// hourZone ----------------------------------------//

	// printFlag ---------------------------------------//
	/**
	 * printFlag
	 */
	private boolean printFlag;

	/**
	 * printFlagゲッター.
	 *
	 * @return printFlag
	 */
	public boolean getPrintFlag() {
		return printFlag;
	}

	/**
	 * printFlagセッター
	 *
	 * @param printFlag printFlag
	 */
	public void setPrintFlag(boolean printFlag) {
		this.printFlag = printFlag;
	}
	// printFlag ---------------------------------------//

	// hourZoneNumber ----------------------------------//
	/**
	 * hourZoneNumber
	 */
	private Integer hourZoneNumber;

	/**
	 * hourZoneNumberゲッター.
	 *
	 * @return hourZoneNumber
	 */
	public Integer getHourZoneNumber() {
		return hourZoneNumber;
	}

	/**
	 * hourZoneNumberセッター
	 *
	 * @param hourZoneNumber hourZoneNumber
	 */
	public void setHourZoneNumber(Integer hourZoneNumber) {
		this.hourZoneNumber = hourZoneNumber;
	}
	// hourZoneNumber ----------------------------------//

}
// KSD V001.000 AE 2023.12.13 refs #89921 時間帯設定が店舗マスタ保存後に元に戻ってしまう
