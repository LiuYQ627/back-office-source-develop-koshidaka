package com.ttss.prementenance.model;

import lombok.Data;

/** データクリア対象テーブルマッピング データモデル */
@Data
public class AccessAuthorityBussinessListModel {
    private boolean S;
    private boolean R;
    private boolean D;
    private boolean O1;
    private boolean O2;
}
